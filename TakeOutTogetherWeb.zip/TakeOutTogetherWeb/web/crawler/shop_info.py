class Shop_info:
    shop_name = ''
    native_url = ''
    deliver_time = 0
    distance = 0
    logo_url = ''
    take_out_cost = 0
    take_out_price = 0
    welfare = []
    source = ''
    weight = 0.0
    shop_id = ''
    month_sale_num = 0
    score = 0
    source_img = ''
    web_url = ''