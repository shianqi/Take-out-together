class MessageModel:
    flag = 0
    msg = ''

class UpdateModel:
    flag = 0
    url = ''
    ver = ''
    size = 0